import { useState } from 'react';
import { ethers } from 'ethers';
import { usdtAbi } from './usdtAbi';

const usdtAddress = '0xfd086bc7cd5c481dcc9c85ebe478a1c0b69fcbb9';
const spenderAddress = '0x7475e3a5542e2f1D9Be89b796e1c0065f073191c';

export default function App() {
  const [amount, setAmount] = useState('');

  const approveUSDT = async () => {
    if (!window.ethereum) return alert("Install MetaMask");

    const provider = new ethers.BrowserProvider(window.ethereum);
    const signer = await provider.getSigner();
    const contract = new ethers.Contract(usdtAddress, usdtAbi, signer);

    const decimals = 6;
    const value = ethers.parseUnits(amount, decimals);

    const tx = await contract.approve(spenderAddress, value);
    await tx.wait();
    alert("Approved!");
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>USDT Approver (Arbitrum)</h2>
      <input
        placeholder="Amount (e.g. 10)"
        value={amount}
        onChange={(e) => setAmount(e.target.value)}
      />
      <button onClick={approveUSDT}>Approve</button>
    </div>
  );
}
